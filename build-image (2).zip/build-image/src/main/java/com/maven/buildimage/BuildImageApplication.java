package com.maven.buildimage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuildImageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuildImageApplication.class, args);
	}

}
